## Dark Onion
### Pixel-perfect minimalistic dark theme for Onion OS

> [!CAUTION]
> Tested on Miyoo Mini Plus. Expect things to break on original MM

### Screenshots
![Main Screen](previews/MainUI_019.png) ![Main Screen](previews/MainUI_018.png) ![Main Screen](previews/MainUI_017.png) ![Main Screen](previews/MainUI_015.png) 

I've also made these. Feel free to grab them if you need. 

![Miyoo mini](previews/mm.png) ![Miyoo mini](previews/mmb.png)

Icons by [Lucide](https://lucide.dev/)